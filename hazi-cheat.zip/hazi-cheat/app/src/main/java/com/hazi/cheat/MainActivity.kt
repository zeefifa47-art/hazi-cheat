package com.hazi.cheat

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private val bg = Color.parseColor("#0D0F1A")
    private val card = Color.parseColor("#171A2B")
    private val accent = Color.parseColor("#7C4DFF")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        showLogin()
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun rounded(color: Int, radius: Int) = GradientDrawable().apply {
        setColor(color)
        cornerRadius = dp(radius).toFloat()
    }

    private fun root(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        gravity = Gravity.CENTER_HORIZONTAL
        setBackgroundColor(bg)
        setPadding(dp(24), dp(48), dp(24), dp(24))
    }

    private fun title(text: String) = TextView(this).apply {
        this.text = text
        textSize = 30f
        setTextColor(Color.WHITE)
        typeface = Typeface.DEFAULT_BOLD
        gravity = Gravity.CENTER
        setPadding(0, 0, 0, dp(8))
    }

    private fun subtitle(text: String) = TextView(this).apply {
        this.text = text
        textSize = 13f
        setTextColor(Color.parseColor("#9AA0B8"))
        gravity = Gravity.CENTER
        setPadding(0, 0, 0, dp(28))
    }

    private fun btn(text: String, color: Int, onClick: () -> Unit) = Button(this).apply {
        this.text = text
        setTextColor(Color.WHITE)
        typeface = Typeface.DEFAULT_BOLD
        background = rounded(color, 14)
        isAllCaps = false
        layoutParams = LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, dp(56)
        ).apply { topMargin = dp(12) }
        setOnClickListener { onClick() }
    }

    private fun field(hint: String, password: Boolean) = EditText(this).apply {
        this.hint = hint
        setHintTextColor(Color.parseColor("#5C627A"))
        setTextColor(Color.WHITE)
        background = rounded(card, 12)
        setPadding(dp(16), dp(14), dp(16), dp(14))
        inputType = if (password)
            InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        else InputType.TYPE_CLASS_TEXT
        layoutParams = LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
        ).apply { topMargin = dp(12) }
    }

    private fun showLogin() {
        val r = root()
        r.addView(title("HAZI CHEAT"))
        r.addView(subtitle("Masuk untuk melanjutkan"))
        val user = field("Username", false)
        val pass = field("Password", true)
        r.addView(user)
        r.addView(pass)
        r.addView(btn("MASUK", accent) {
            if (user.text.toString().trim() == "hazi" && pass.text.toString() == "hazi") {
                showMain()
            } else {
                Toast.makeText(this, "Username atau password salah", Toast.LENGTH_SHORT).show()
            }
        })
        setContentView(r)
    }

    private fun showMain() {
        val r = root()
        r.addView(title("HAZI CHEAT"))
        r.addView(subtitle("Role: OWNER  •  Expired: Unlimited"))
        r.addView(btn("MULAI FF MAX", accent) { startGame("com.dts.freefiremax") })
        r.addView(btn("MULAI FF BIASA", Color.parseColor("#2E7DFF")) { startGame("com.dts.freefireth") })
        r.addView(btn("Tentang Aplikasi", card) { showAbout() })
        r.addView(btn("Keluar", card) { stopService(Intent(this, FloatingService::class.java)); showLogin() })
        setContentView(r)
    }

    private fun showAbout() {
        AlertDialog.Builder(this)
            .setTitle("Tentang")
            .setMessage(
                "HAZI CHEAT adalah UI demo. Semua toggle di panel (Aimlock, Aim Recoil, " +
                    "Rege, HaziXit) hanya tampilan dan tidak memengaruhi game apa pun."
            )
            .setPositiveButton("OK", null)
            .show()
    }

    private fun startGame(pkg: String) {
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Izinkan tampil di atas aplikasi lain dulu", Toast.LENGTH_LONG).show()
            startActivity(
                Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
            )
            return
        }
        val launch = packageManager.getLaunchIntentForPackage(pkg)
        if (launch == null) {
            Toast.makeText(this, "Free Fire belum terpasang", Toast.LENGTH_LONG).show()
            return
        }
        startService(Intent(this, FloatingService::class.java))
        startActivity(launch)
    }
}
